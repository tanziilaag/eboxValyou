<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">    
    
    <!-- My CSS -->
    <link rel="stylesheet" href="beranda1.css">

    <!-- AOS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

    <title>Beranda</title>
  </head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="img/logo.png" width="35" height="100%" class="d-inline-block align-top" alt="">
                 eBox</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ml-auto">
                <a class="nav-item nav-link active" href="#">Beranda</a>
                <a class="nav-item nav-link" href="../tentang/tentang.php">Tentang</a>
                <a class="nav-item btn btn-primary tombol" href="../daftarLogin/indexLogin.php">Login</a>
            </div>
            </div>
        </div>
    </nav>


    <div class="konten">
    <!-- Jumbotron -->
    <div class="jumbotron jumbotron-fluid" >
        <div class="container">
            <div class="row atas">
                <div class="col-lg-6 my-auto ml-3"> 
                    <h1><strong>Tingkatkan penjualan <br> dengan inventory <br> management online</strong></h1>
                    <p class ="mt-4">Mengubah cara setiap bisnis dalam melakukan <br> inventorisasi barang dengan mudah dan efisien.</p>
                    <button type="button" class="btn btn-primary btn-lg " id="btnDaftar"><a style="text-decoration: none; color: white; font-size: 22px;" href="../daftarLogin/indexDaftar.php"><Strong>Daftar Sekarang</Strong></a></button>
                </div>
                <div class="col ml-3">
                    <img src="img/home 1-01 1.png" class="img-fluid" >
                </div>
            </div>
        </div>
    </div>

    <!-- Apa yang bisa dilakukan Ebox-->
    <div class="container">
        <div class="row text-center ">
          <div class="col ml-1">
            <h2>Apa yang bisa dilakukan eBox?</h2>
            <p><span class="eBoxFont">eBox</span> adalah aplikasi berbasis web siap membantu bisnis Anda jadi lebih jauh efektif dan efisien</p>
          </div>
        </div>
        <div class="row justify-content-center text-center" id="ebox">
          <div class="col-lg-2 col-md-3 col-sm-4 col-6">
            <img src="img/perbarui.png" alt="" width="220">
            <h6>Perbarui Data <br>   dimanapun</h6>
          </div>
          <div class="col-lg-2 col-md-3 col-sm-4 col-6">
            <img src="img/mengelola.png" alt="" width="220">
            <h6>Mengelola Stok <br>Barang</h6>
          </div>
          <div class="col-lg-2 col-md-3 col-sm-4 col-6">
            <img src="img/riwayat.png" alt="" width="220" class="pb-3">
            <h6>Riwayat Data <br> Barang</h6>
          </div>
        </div>
      </div>

    <!-- Fitur Ebox-->
      <div class="container">
        <div class="row text-center" >
          <div class="col ml-1">
            <h2>Fitur Pintar eBox</h2>
            <p>Gunakan fitur pintar milik eBox untuk membuat inventory yang lebih keren</p>
          </div>
        </div>
        <div class="row justify-content-center text-center" id="fitur">
          <div class="col-lg-2 col-md-3 col-sm-4 col-6">
            <img src="img/multiple.png" alt="" width="110">
            <h6>Multiple <br> warehouse</h6>
          </div>
          <div class="col-lg-2 col-md-3 col-sm-4 col-6">
            <img src="img/riwayat2.png" alt="" width="110">
            <h6>Riwayat <br> transaksi</h6>
          </div>
          <div class="col-lg-2 col-md-3 col-sm-4 col-6">
            <img src="img/detailProd.png" alt="" width="110">
            <h6>Detail <br> produk</h6>
          </div>
        </div>
      </div>

    <!-- stok in/out Ebox-->
      <div class="container">
        <div class="row justify-content-center" id="stok">
          <div class="col-lg-6 col-md-7 col-sm-12 mx-auto text-center">
            <img src="img/Group 67.png"  width="450" alt="" class="stok">
          </div>
          <div class="col-lg-5 col-md-7 col-sm-10 mx-auto my-auto">
            <div class="row justify-content-center">
                <div class="col-9 col-sm-12 my-4">
                    <h2>Stok Masuk dan Stok Keluar dengan sekali klik! </h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-3 col-md-2 text-right">
                    <img src="img/logout.png" alt="">
                </div>
                <div class="col-9 col-md-10 mx-auto">
                    <p>Perbarui jumlah stok dimanapun <br> dan kapanpun!</p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-3 col-md-2 text-right">
                    <img src="img/switch-vertical.png" alt="">
                </div>
                <div class="col-9 col-md-10 mx-auto">
                    <p>Segera catat barang yang telah <br> Anda jual di stok keluar!</p>
                 </div>
            </div>
          </div>
        </div>
      </div>
      
    <!-- Gambar Ebox-->
      <div class="container">
        <div class="row justify-content-center">
          <div class="col  mx-auto text-center">
            <img src="img/Group 38.png" width="400" alt="" class="order">
          </div>
        </div>
      </div>
    


    <!-- Testimoni Ebox-->
    <div class="container">
        <h2 class="ml-1"><strong>Testimoni</strong></h2>
        <br>
        <div class="row" id="testimoni">
          <div class="col-lg-3 col-md-6">
            <div class="card">
              <img src="img/tanziila.png" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Tanziila Aziizi</h5>
                <p class="card-text zila">Direktur Umum Betamart</p>
                <p class="card-text">eBox sangat membantu dalam memantau stok barang di toko saya jadi saya tidak kehabisan stok. Maju terus dan jaya selalu buat eBox ...</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="card">
              <img src="img/juan.png" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Juan Parez</h5>
                <p class="card-text juan">Peternak Ikan Lele</p>
                <p class="card-text">Dulu sebelum menggunakan eBox saya kebingungan dalam mendata stok pakan ikan lele, kini saya sudah tidak bingung lagi...</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="card">
              <img src="img/nabila.png" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Nabila Putri</h5>
                <p class="card-text bila">Pengusaha Fashion</p>
                <p class="card-text">Saya sangat suka dengan fitur melihat history stok masuk dan keluar sehingga memudahkan saya dalam membuat
                  laporan penjualan...
                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="card">
              <img src="img/naela.png" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Naela Fauzul</h5>
                <p class="card-text ela">Pengusaha Warehouse</p>
                <p class="card-text">Baru tau ada web dengan fitur se-keren ini, sayang sekali saya baru mengetauinya akhir tahun 2022 ini.
                  Jaya terus eBox...
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

        <div class="footer"> 
            <div class="textFooter mx-3">          
                <h4>
                    Layanan Pengaduan Konsumen
                    
                </h4>               
                <hr>               
                <p>PT. Valyou Barokah</p>                
                <p>
                    email : valyoubarokah@gmail.com
                </p>
                <h6>
                    Direktorat Jenderal Perlindungan Konsumen dan Tertib Niaga
                    <br>
                    Kementerian Perdagangan Republik Indonesia
                    <br>
                </h6>
                <p>
                    Whatsapp Pengaduan Konsumen Ditjen PKTN: 0853-1111-1010
                </p> 
            </div>            
        </div>
    </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

</body>
</html>